﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using c_auth;

namespace c_auth
{
    class Program
    {
        static void watermark() {
            Console.Clear();
            Console.WriteLine("--> cAuth Example <--");
        }

        public static api auth_instance = new api("version", "program_key", "api_key", show_messages: true);
        static void Main(string[] args) {
            string user, email, pass, token;

            auth_instance.init();

            watermark();
            Console.WriteLine("write your option : \n1) Login\n2) Register\n3) Activate\n4) All In One");

            int option = Convert.ToInt32(Console.ReadLine());
            switch (option) {
                case 1:
                    watermark();

                    Console.WriteLine("write your username : ");
                    user = Console.ReadLine();

                    watermark();

                    Console.WriteLine("now write your password : ");
                    pass = Console.ReadLine();

                    watermark();

                    if (auth_instance.login(user, pass)) {
                    	var user_data = auth_instance.user_data;
                    	
                        Console.WriteLine("logged in successfully !!!");

                        Console.WriteLine(user_data.username);
                        Console.WriteLine(user_data.email);
                        Console.WriteLine(user_data.expires);
                        Console.WriteLine(user_data.var);
                        Console.WriteLine(user_data.rank);
                    }
                    else {
                        Console.WriteLine(":ddd !!!");
                    }
                    break;

                case 2:
                    watermark();

                    Console.WriteLine("write your username : ");
                    user = Console.ReadLine();

                    watermark();

                    Console.WriteLine("now write your email : ");
                    email = Console.ReadLine();

                    watermark();

                    Console.WriteLine("write your pass : ");
                    pass = Console.ReadLine();

                    watermark();

                    Console.WriteLine("now your token!! : ");
                    token = Console.ReadLine();

                    watermark();

                    if (auth_instance.register(user, email, pass, token))
                        Console.WriteLine("registered successfully!!");
                    else
                        Console.WriteLine(":(((");
                    break;

                case 3:
                    watermark();

                    Console.WriteLine("write your username : ");
                    user = Console.ReadLine();

                    watermark();

                    Console.WriteLine("now, write your token : ");
                    token = Console.ReadLine();

                    watermark();

                    if (auth_instance.activate(user, token))
                        Console.WriteLine("activated successfully!!");
                    else
                        Console.WriteLine(":(((");
                    break;

                case 4:
                    watermark();

                    Console.WriteLine("write your token : ");
                    token = Console.ReadLine();

                    watermark();

                    if (auth_instance.all_in_one(token)) {
                    	var user_data = auth_instance.user_data;
                    	
                        Console.WriteLine("logged in successfully !!!");

                        Console.WriteLine(user_data.username);
                        Console.WriteLine(user_data.email);
                        Console.WriteLine(user_data.expires);
                        Console.WriteLine(user_data.var);
                        Console.WriteLine(user_data.rank);
                    }
                    else {
                        Console.WriteLine(":ddd !!!");
                    }
                    break;

                default:
                    watermark();

                    Console.WriteLine("not available option");
                    break;
            }

            Console.ReadLine();
        }
    }
}
