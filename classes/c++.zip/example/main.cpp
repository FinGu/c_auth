// example.cpp : Este arquivo contém a função 'main'. A execução do programa começa e termina ali.
//

#include <iostream>
#include "api/c_auth.hpp"

void watermark() {
    system("cls"); 
    std::cout << "--> cAuth Example <--" << std::endl;
}

std::string tm_to_readable_time(tm ctx) {
    char buffer[25];

    strftime(buffer, sizeof(buffer), "%m/%d/%y", &ctx);

    return std::string(buffer);
}

c_auth::api auth_instance(c_xor("version"), c_xor("program_key"), c_xor("api_key"));

int main()
{
    int option;

    std::string user, email, pass, token;

    auth_instance.init();

    watermark();

    std::cout << "write your option : \n1) Login\n2) Register\n3) Activate\n4) All In One\n";
    std::cin >> option;

    switch (option) {
        case 1:
            watermark();

            std::cout << "write your username : \n";
            std::cin >> user;

            watermark();

            std::cout << "now write your password : \n";
            std::cin >> pass;

            watermark();

            if (auth_instance.login(user, pass)) {
                std::cout << "logged in successfully !!!\n";

                std::cout << auth_instance.user_data.username << std::endl;
                std::cout << auth_instance.user_data.email << std::endl;
                std::cout << tm_to_readable_time(auth_instance.user_data.expires) << std::endl;
                std::cout << auth_instance.user_data.var << std::endl;
                std::cout << auth_instance.user_data.rank << std::endl;
            }
            else {
                std::cout << ":ddd !!!";
            }
            break;

        case 2:
            watermark();

            std::cout << "write your username : \n";
            std::cin >> user;

            watermark();

            std::cout << "now write your email : \n";
            std::cin >> email;

            watermark();

            std::cout << "write your pass : \n";
            std::cin >> pass;

            watermark();

            std::cout << "now your token!! : \n";
            std::cin >> token;

            watermark();

            if (auth_instance.register(user, email, pass, token))
                std::cout << "registered successfully!!";
            else
                std::cout << ":(((";

            break;

        case 3:
            watermark();

            std::cout << "write your username : \n";
            std::cin >> user;
            
            watermark();

            std::cout << "for the last, write your token : \n";
            std::cin >> token;

            watermark();

            if (auth_instance.activate(user, token))
                std::cout << "activated successfully!!";
            else
                std::cout << ":(((";

            break;

        case 4:
            watermark();

            std::cout << "write your token : \n";
            std::cin >> token;

            watermark();

            if (auth_instance.all_in_one(token)) {
                std::cout << "Logged in successfully !!!\n";

                std::cout << auth_instance.user_data.username << std::endl;
                std::cout << auth_instance.user_data.email << std::endl;
                std::cout << tm_to_readable_time(auth_instance.user_data.expires) << std::endl;
                std::cout << auth_instance.user_data.var << std::endl;
                std::cout << auth_instance.user_data.rank << std::endl;
            }
            else {
                std::cout << ":ddd !!!";
            }
            break;

        default:
            watermark();

            std::cout << "not available option\n";
            break;
    }

    std::cin >> option;
}

