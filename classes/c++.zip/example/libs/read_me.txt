to use the example in release-x86-windows
unpack this rar file : https://cauth.me/classes/libs/x86.rar into this folder

to use the example in release-x64-windows
unpack this zip file : https://cauth.me/classes/libs/x64.rar into this folder

if you want different compilation settings, compile CryptoPP and cURL[OPENSSL] in the mode you want

this packages were installed with vcpkg

